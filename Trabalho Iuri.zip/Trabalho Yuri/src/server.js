const express = require('express');
const fs = require('fs');
const cors = require('cors');

const server = express();
server.use(cors());
server.use(express.json());

const dados = require('./data/dados.json');

server.delete('/mangas/:id', (req, res) => {
    const id = parseInt(req.params.id);

    const indiceRemocao = dados.Mangas.findIndex(m => m.id === id);
    if (indiceRemocao !== -1) {
        dados.Mangas.splice(indiceRemocao, 1);

        dados.Mangas.forEach((mang, index) => {
            mang.id = index + 1;
        });

        salvarDados(dados);
        return res.status(200).json({ mensagem: "Mangá excluída com sucesso." });
    }
});

server.post('/mangas', (req, res) => {
    const novoManga = req.body;

    if (!novoManga.id || !novoManga.nome || !novoManga.artista || !novoManga.genero || !novoManga.imagem) {
        return res.status(400).json({ mensagem: "Dados incompletos, tente novamente" });
    } else {
        dados.Mangas.push(novoManga);
        salvarDados(dados);

        return res.status(201).json({ mensagem: "Dados completos, cadastro feito com sucesso!" });
    }
});

server.put('/mangas/:id', (req, res) => {
    const mangasId = parseInt(req.params.id);
    const atualizarManga = req.body;

    const indiceManga = dados.mangas.findIndex(manga => manga.id === mangasId);

    if (indiceManga === -1) {
        return res.status(404).json({ mensagem: "Mangá não encontrada" });
    }

    dados.mangas[indiceManga].nome = atualizarManga.nome || dados.mangas[indiceManga].nome;
    dados.mangas[indiceManga].artista = atualizarManga.artista || dados.mangas[indiceManga].artista;
    dados.mangas[indiceManga].genero = atualizarManga.genero || dados.mangas[indiceManga].genero;
    dados.mangas[indiceManga].imagem = atualizarManga.imagem || dados.mangas[indiceManga].imagem;

    salvarDados(dados);

    return res.json({ mensagem: "Manga atualizada com sucesso", manga: dados.mangas[indiceManga] });
});

server.get('/mangas', (req, res) => {
    return res.json(dados.Mangas);
});

function salvarDados(dados) {
    fs.writeFileSync(__dirname + '/data/dados.json', JSON.stringify(dados, null, 2));
}

server.listen(4000, () => {
    console.log("Servidor rodando na porta 4000");
});