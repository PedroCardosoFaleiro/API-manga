//adicionar

 function addManga() {

    const ID = document.getElementById('id').value
    const nome = document.getElementById('name').value
    const artista = document.getElementById('artist').value
    const genero = document.getElementById('genre').value
    const imagem = document.getElementById('image').value

    fetch('http://localhost:4000/mangas', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: ID,
            nome: nome,
            artista: artista,
            genero: genero,
            imagem: imagem
        }),
    })
        .then(response => response.json())
        .then(data => {
            console.log(data)
        })
        .catch(error => console.error("Erro:", error))
}

//deletar

function deleteManga(mangaId){
    const man = parseInt(mangaId)
    fetch(`http://localhost:4000/mangas/${man}`, {
        method: 'DELETE',
    })
    .then(response => response.json())
    .then(data => {
        alert('Apagado!')
    })
    .catch(error => alert("Error:", error));
}

//atualizar

    const editarId = document.getElementById('id').value;
    const editarNome = document.getElementById('name').value;
    const editarAutor = document.getElementById('artist').value;
    const editarGenero = document.getElementById('genre').value;
    const editarImagem = document.getElementById('image').value;


function atualizarManga(mangaId){

    const id = parseInt(mangaId)

    fetch(`http://localhost:4000/mangas/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: editarId,
            nome: editarNome,
            artista: editarAutor,
            genero: editarGenero,
            imagem: editarImagem
        }),
    })
        .then(response => response.json())
        .then(data => {
            console.log(data)
        })
        .catch(error => console.error("Erro:", error))

        .then(() => {
            window.location.href = 'index.html';
        })
}